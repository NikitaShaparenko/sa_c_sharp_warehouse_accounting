﻿namespace DropDownControl_CSharp
{
    partial class DropDownForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Top_button = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.exit_button = new System.Windows.Forms.Button();
            this.aboutpaint_button = new System.Windows.Forms.Button();
            this.properties_button = new System.Windows.Forms.Button();
            this.seninemail_button = new System.Windows.Forms.Button();
            this.print_button = new System.Windows.Forms.Button();
            this.saveAs_button = new System.Windows.Forms.Button();
            this.save_button = new System.Windows.Forms.Button();
            this.open_button = new System.Windows.Forms.Button();
            this.new_button = new System.Windows.Forms.Button();
            this.optionsPanel = new System.Windows.Forms.Panel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel7.SuspendLayout();
            this.panel10.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(471, 1);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 415);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(470, 1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1, 415);
            this.panel3.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(1, 415);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(469, 1);
            this.panel4.TabIndex = 3;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(1, 401);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(469, 14);
            this.panel5.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(1, 400);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(469, 1);
            this.panel6.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.Controls.Add(this.Top_button);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(1, 1);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(469, 25);
            this.panel7.TabIndex = 6;
            // 
            // Top_button
            // 
            this.Top_button.BackColor = System.Drawing.Color.Navy;
            this.Top_button.FlatAppearance.BorderSize = 0;
            this.Top_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Top_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Top_button.ForeColor = System.Drawing.Color.White;
            this.Top_button.Location = new System.Drawing.Point(0, 0);
            this.Top_button.Name = "Top_button";
            this.Top_button.Size = new System.Drawing.Size(70, 25);
            this.Top_button.TabIndex = 0;
            this.Top_button.Text = "File";
            this.Top_button.UseVisualStyleBackColor = false;
            this.Top_button.Click += new System.EventHandler(this.Top_button_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(1, 26);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(469, 1);
            this.panel8.TabIndex = 7;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Silver;
            this.panel9.Location = new System.Drawing.Point(193, 29);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1, 372);
            this.panel9.TabIndex = 8;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.panel12);
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Controls.Add(this.exit_button);
            this.panel10.Controls.Add(this.aboutpaint_button);
            this.panel10.Controls.Add(this.properties_button);
            this.panel10.Controls.Add(this.seninemail_button);
            this.panel10.Controls.Add(this.print_button);
            this.panel10.Controls.Add(this.saveAs_button);
            this.panel10.Controls.Add(this.save_button);
            this.panel10.Controls.Add(this.open_button);
            this.panel10.Controls.Add(this.new_button);
            this.panel10.Location = new System.Drawing.Point(2, 27);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(190, 372);
            this.panel10.TabIndex = 9;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Silver;
            this.panel12.Location = new System.Drawing.Point(42, 247);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(150, 1);
            this.panel12.TabIndex = 10;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Silver;
            this.panel11.Location = new System.Drawing.Point(42, 163);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(150, 1);
            this.panel11.TabIndex = 9;
            // 
            // exit_button
            // 
            this.exit_button.FlatAppearance.BorderSize = 0;
            this.exit_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.exit_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.exit_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exit_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit_button.Location = new System.Drawing.Point(0, 332);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(190, 40);
            this.exit_button.TabIndex = 8;
            this.exit_button.Text = "E&xit";
            this.toolTip1.SetToolTip(this.exit_button, "Exit.....!");
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            this.exit_button.MouseEnter += new System.EventHandler(this.exit_button_MouseEnter);
            // 
            // aboutpaint_button
            // 
            this.aboutpaint_button.FlatAppearance.BorderSize = 0;
            this.aboutpaint_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.aboutpaint_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.aboutpaint_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.aboutpaint_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutpaint_button.Location = new System.Drawing.Point(0, 291);
            this.aboutpaint_button.Name = "aboutpaint_button";
            this.aboutpaint_button.Size = new System.Drawing.Size(190, 40);
            this.aboutpaint_button.TabIndex = 7;
            this.aboutpaint_button.Text = "Abou&t Paint";
            this.toolTip1.SetToolTip(this.aboutpaint_button, "About Paint");
            this.aboutpaint_button.UseVisualStyleBackColor = true;
            this.aboutpaint_button.MouseEnter += new System.EventHandler(this.aboutpaint_button_MouseEnter);
            // 
            // properties_button
            // 
            this.properties_button.FlatAppearance.BorderSize = 0;
            this.properties_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.properties_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.properties_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.properties_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.properties_button.Location = new System.Drawing.Point(0, 250);
            this.properties_button.Name = "properties_button";
            this.properties_button.Size = new System.Drawing.Size(190, 40);
            this.properties_button.TabIndex = 6;
            this.properties_button.Text = "Prop&erties";
            this.toolTip1.SetToolTip(this.properties_button, "Properties");
            this.properties_button.UseVisualStyleBackColor = true;
            this.properties_button.MouseEnter += new System.EventHandler(this.properties_button_MouseEnter);
            // 
            // seninemail_button
            // 
            this.seninemail_button.FlatAppearance.BorderSize = 0;
            this.seninemail_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.seninemail_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.seninemail_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.seninemail_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seninemail_button.Location = new System.Drawing.Point(0, 207);
            this.seninemail_button.Name = "seninemail_button";
            this.seninemail_button.Size = new System.Drawing.Size(190, 40);
            this.seninemail_button.TabIndex = 5;
            this.seninemail_button.Text = "Sen&d in email";
            this.toolTip1.SetToolTip(this.seninemail_button, "Send in email");
            this.seninemail_button.UseVisualStyleBackColor = true;
            this.seninemail_button.MouseEnter += new System.EventHandler(this.sendinemail_button_MouseEnter);
            // 
            // print_button
            // 
            this.print_button.FlatAppearance.BorderSize = 0;
            this.print_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.print_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.print_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.print_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.print_button.Image = global::DropDownControl_CSharp.Properties.Resources.print;
            this.print_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.print_button.Location = new System.Drawing.Point(0, 166);
            this.print_button.Name = "print_button";
            this.print_button.Size = new System.Drawing.Size(190, 40);
            this.print_button.TabIndex = 4;
            this.print_button.Text = "&Print";
            this.toolTip1.SetToolTip(this.print_button, "Print Options");
            this.print_button.UseVisualStyleBackColor = true;
            this.print_button.MouseEnter += new System.EventHandler(this.print_button_MouseEnter);
            // 
            // saveAs_button
            // 
            this.saveAs_button.FlatAppearance.BorderSize = 0;
            this.saveAs_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.saveAs_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.saveAs_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveAs_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveAs_button.Image = global::DropDownControl_CSharp.Properties.Resources.save_as;
            this.saveAs_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveAs_button.Location = new System.Drawing.Point(0, 123);
            this.saveAs_button.Name = "saveAs_button";
            this.saveAs_button.Size = new System.Drawing.Size(190, 40);
            this.saveAs_button.TabIndex = 3;
            this.saveAs_button.Text = "Save &as";
            this.toolTip1.SetToolTip(this.saveAs_button, "Save As Options");
            this.saveAs_button.UseVisualStyleBackColor = true;
            this.saveAs_button.MouseEnter += new System.EventHandler(this.saveAs_button_MouseEnter);
            this.saveAs_button.MouseLeave += new System.EventHandler(this.saveAs_button_MouseLeave);
            // 
            // save_button
            // 
            this.save_button.FlatAppearance.BorderSize = 0;
            this.save_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.save_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.save_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.save_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save_button.Image = global::DropDownControl_CSharp.Properties.Resources.save;
            this.save_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.save_button.Location = new System.Drawing.Point(0, 82);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(190, 40);
            this.save_button.TabIndex = 2;
            this.save_button.Text = "&Save";
            this.toolTip1.SetToolTip(this.save_button, "Save");
            this.save_button.UseVisualStyleBackColor = true;
            this.save_button.MouseEnter += new System.EventHandler(this.save_button_MouseEnter);
            // 
            // open_button
            // 
            this.open_button.FlatAppearance.BorderSize = 0;
            this.open_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.open_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.open_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.open_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.open_button.Image = global::DropDownControl_CSharp.Properties.Resources.Open_images;
            this.open_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.open_button.Location = new System.Drawing.Point(0, 41);
            this.open_button.Name = "open_button";
            this.open_button.Size = new System.Drawing.Size(190, 40);
            this.open_button.TabIndex = 1;
            this.open_button.Text = "&Open";
            this.toolTip1.SetToolTip(this.open_button, "Open");
            this.open_button.UseVisualStyleBackColor = true;
            this.open_button.MouseEnter += new System.EventHandler(this.open_button_MouseEnter);
            // 
            // new_button
            // 
            this.new_button.FlatAppearance.BorderSize = 0;
            this.new_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.new_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(240)))), ((int)(((byte)(250)))));
            this.new_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.new_button.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.new_button.Image = global::DropDownControl_CSharp.Properties.Resources.images2;
            this.new_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.new_button.Location = new System.Drawing.Point(0, 0);
            this.new_button.Name = "new_button";
            this.new_button.Size = new System.Drawing.Size(190, 40);
            this.new_button.TabIndex = 0;
            this.new_button.Text = "&New";
            this.toolTip1.SetToolTip(this.new_button, "New");
            this.new_button.UseVisualStyleBackColor = true;
            this.new_button.MouseEnter += new System.EventHandler(this.new_button_MouseEnter);
            // 
            // optionsPanel
            // 
            this.optionsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.optionsPanel.Location = new System.Drawing.Point(193, 27);
            this.optionsPanel.Name = "optionsPanel";
            this.optionsPanel.Size = new System.Drawing.Size(275, 374);
            this.optionsPanel.TabIndex = 10;
            // 
            // DropDownForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(471, 416);
            this.ControlBox = false;
            this.Controls.Add(this.optionsPanel);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DropDownForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "DropDownForm";
            this.panel7.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button new_button;
        private System.Windows.Forms.Button open_button;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.Button print_button;
        private System.Windows.Forms.Button saveAs_button;
        private System.Windows.Forms.Button seninemail_button;
        private System.Windows.Forms.Button properties_button;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Button aboutpaint_button;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel optionsPanel;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button Top_button;
    }
}