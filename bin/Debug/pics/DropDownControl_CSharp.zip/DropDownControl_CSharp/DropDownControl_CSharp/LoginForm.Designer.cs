﻿namespace DropDownControl_CSharp
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelZ1 = new DropDownControl_CSharp.PanelZ();
            this.shapedButton1 = new DropDownControl_CSharp.ShapedButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panelZ1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelZ1
            // 
            this.panelZ1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelZ1.Controls.Add(this.shapedButton1);
            this.panelZ1.Controls.Add(this.textBox2);
            this.panelZ1.Controls.Add(this.label3);
            this.panelZ1.Controls.Add(this.textBox1);
            this.panelZ1.Controls.Add(this.label2);
            this.panelZ1.Controls.Add(this.label1);
            this.panelZ1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelZ1.EndColor = System.Drawing.Color.DarkBlue;
            this.panelZ1.GradientAngle = 90;
            this.panelZ1.Location = new System.Drawing.Point(0, 0);
            this.panelZ1.Name = "panelZ1";
            this.panelZ1.Size = new System.Drawing.Size(459, 251);
            this.panelZ1.StartColor = System.Drawing.Color.DodgerBlue;
            this.panelZ1.TabIndex = 0;
            this.panelZ1.Transparent1 = 255;
            this.panelZ1.Transparent2 = 255;
            // 
            // shapedButton1
            // 
            this.shapedButton1.BackColor = System.Drawing.Color.Transparent;
            this.shapedButton1.BorderColor = System.Drawing.Color.Transparent;
            this.shapedButton1.BorderWidth = 1;
            this.shapedButton1.ButtonShape = DropDownControl_CSharp.ShapedButton.ButtonsShapes.RoundRect;
            this.shapedButton1.ButtonText = "Sign In";
            this.shapedButton1.EndColor = System.Drawing.Color.MidnightBlue;
            this.shapedButton1.FlatAppearance.BorderSize = 0;
            this.shapedButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.shapedButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.shapedButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.shapedButton1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shapedButton1.ForeColor = System.Drawing.Color.White;
            this.shapedButton1.GradientAngle = 90;
            this.shapedButton1.Location = new System.Drawing.Point(278, 170);
            this.shapedButton1.MouseClickColor1 = System.Drawing.Color.Yellow;
            this.shapedButton1.MouseClickColor2 = System.Drawing.Color.Red;
            this.shapedButton1.MouseHoverColor1 = System.Drawing.Color.Turquoise;
            this.shapedButton1.MouseHoverColor2 = System.Drawing.Color.DarkSlateGray;
            this.shapedButton1.Name = "shapedButton1";
            this.shapedButton1.ShowButtontext = true;
            this.shapedButton1.Size = new System.Drawing.Size(125, 46);
            this.shapedButton1.StartColor = System.Drawing.Color.DodgerBlue;
            this.shapedButton1.TabIndex = 5;
            this.shapedButton1.Text = "Sign In";
            this.shapedButton1.TextLocation_X = 35;
            this.shapedButton1.TextLocation_Y = 12;
            this.shapedButton1.Transparent1 = 250;
            this.shapedButton1.Transparent2 = 250;
            this.shapedButton1.UseVisualStyleBackColor = false;
            this.shapedButton1.Click += new System.EventHandler(this.shapedButton1_Click);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBox2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.White;
            this.textBox2.Location = new System.Drawing.Point(172, 124);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(231, 28);
            this.textBox2.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(50, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Password : ";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.textBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(173, 78);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(230, 28);
            this.textBox1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(45, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(19, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sign in";
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 251);
            this.ControlBox = false;
            this.Controls.Add(this.panelZ1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoginForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "LoginForm";
            this.panelZ1.ResumeLayout(false);
            this.panelZ1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private PanelZ panelZ1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private ShapedButton shapedButton1;
    }
}