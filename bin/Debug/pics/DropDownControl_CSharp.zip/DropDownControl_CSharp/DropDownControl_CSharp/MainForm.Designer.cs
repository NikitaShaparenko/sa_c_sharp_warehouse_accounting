﻿namespace DropDownControl_CSharp
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelZ1 = new DropDownControl_CSharp.PanelZ();
            this.shapedButton2 = new DropDownControl_CSharp.ShapedButton();
            this.shapedButton1 = new DropDownControl_CSharp.ShapedButton();
            this.panelZ1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelZ1
            // 
            this.panelZ1.Controls.Add(this.shapedButton2);
            this.panelZ1.Controls.Add(this.shapedButton1);
            this.panelZ1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelZ1.EndColor = System.Drawing.Color.DodgerBlue;
            this.panelZ1.GradientAngle = 90;
            this.panelZ1.Location = new System.Drawing.Point(0, 0);
            this.panelZ1.Name = "panelZ1";
            this.panelZ1.Size = new System.Drawing.Size(364, 246);
            this.panelZ1.StartColor = System.Drawing.Color.Cyan;
            this.panelZ1.TabIndex = 0;
            this.panelZ1.Transparent1 = 255;
            this.panelZ1.Transparent2 = 255;
            // 
            // shapedButton2
            // 
            this.shapedButton2.BackColor = System.Drawing.Color.Transparent;
            this.shapedButton2.BorderColor = System.Drawing.Color.Transparent;
            this.shapedButton2.BorderWidth = 1;
            this.shapedButton2.ButtonShape = DropDownControl_CSharp.ShapedButton.ButtonsShapes.RoundRect;
            this.shapedButton2.ButtonText = "DropDownControl by TabControl";
            this.shapedButton2.EndColor = System.Drawing.Color.MidnightBlue;
            this.shapedButton2.FlatAppearance.BorderSize = 0;
            this.shapedButton2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.shapedButton2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.shapedButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.shapedButton2.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shapedButton2.ForeColor = System.Drawing.Color.White;
            this.shapedButton2.GradientAngle = 90;
            this.shapedButton2.Location = new System.Drawing.Point(12, 130);
            this.shapedButton2.MouseClickColor1 = System.Drawing.Color.Red;
            this.shapedButton2.MouseClickColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.shapedButton2.MouseHoverColor1 = System.Drawing.Color.Turquoise;
            this.shapedButton2.MouseHoverColor2 = System.Drawing.Color.DarkSlateGray;
            this.shapedButton2.Name = "shapedButton2";
            this.shapedButton2.ShowButtontext = true;
            this.shapedButton2.Size = new System.Drawing.Size(328, 83);
            this.shapedButton2.StartColor = System.Drawing.Color.DodgerBlue;
            this.shapedButton2.TabIndex = 1;
            this.shapedButton2.Text = "shapedButton2";
            this.shapedButton2.TextLocation_X = 36;
            this.shapedButton2.TextLocation_Y = 30;
            this.shapedButton2.Transparent1 = 250;
            this.shapedButton2.Transparent2 = 250;
            this.shapedButton2.UseVisualStyleBackColor = false;
            this.shapedButton2.Click += new System.EventHandler(this.shapedButton2_Click);
            // 
            // shapedButton1
            // 
            this.shapedButton1.BackColor = System.Drawing.Color.Transparent;
            this.shapedButton1.BorderColor = System.Drawing.Color.Transparent;
            this.shapedButton1.BorderWidth = 1;
            this.shapedButton1.ButtonShape = DropDownControl_CSharp.ShapedButton.ButtonsShapes.RoundRect;
            this.shapedButton1.ButtonText = "DropDownControl by Button";
            this.shapedButton1.EndColor = System.Drawing.Color.MidnightBlue;
            this.shapedButton1.FlatAppearance.BorderSize = 0;
            this.shapedButton1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.shapedButton1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.shapedButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.shapedButton1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.shapedButton1.ForeColor = System.Drawing.Color.White;
            this.shapedButton1.GradientAngle = 90;
            this.shapedButton1.Location = new System.Drawing.Point(12, 12);
            this.shapedButton1.MouseClickColor1 = System.Drawing.Color.Red;
            this.shapedButton1.MouseClickColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.shapedButton1.MouseHoverColor1 = System.Drawing.Color.Turquoise;
            this.shapedButton1.MouseHoverColor2 = System.Drawing.Color.DarkSlateGray;
            this.shapedButton1.Name = "shapedButton1";
            this.shapedButton1.ShowButtontext = true;
            this.shapedButton1.Size = new System.Drawing.Size(328, 83);
            this.shapedButton1.StartColor = System.Drawing.Color.DodgerBlue;
            this.shapedButton1.TabIndex = 0;
            this.shapedButton1.Text = "shapedButton1";
            this.shapedButton1.TextLocation_X = 56;
            this.shapedButton1.TextLocation_Y = 30;
            this.shapedButton1.Transparent1 = 250;
            this.shapedButton1.Transparent2 = 250;
            this.shapedButton1.UseVisualStyleBackColor = false;
            this.shapedButton1.Click += new System.EventHandler(this.shapedButton1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 246);
            this.Controls.Add(this.panelZ1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.panelZ1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private PanelZ panelZ1;
        private ShapedButton shapedButton1;
        private ShapedButton shapedButton2;
    }
}