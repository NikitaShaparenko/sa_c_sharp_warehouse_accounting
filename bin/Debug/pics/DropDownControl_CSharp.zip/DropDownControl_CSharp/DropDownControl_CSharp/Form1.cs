﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DropDownControl_CSharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        public Boolean isShown = false;

        DropDownForm _dropDownForm;

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        protected override void OnMove(EventArgs e)
        {
            base.OnMove(e);
            if (isShown)
            {
                _dropDownForm.Close();
                isShown = false;
                button1.BackColor = Color.RoyalBlue;
            }
        }

        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            if (isShown)
            {
                _dropDownForm.Close();
                isShown = false;
                button1.BackColor = Color.RoyalBlue;
            }
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            if (isShown)
            {
                _dropDownForm.Close();
                isShown = false;
                button1.BackColor = Color.RoyalBlue;
            }
        }


        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
            if (isShown)
            {
                _dropDownForm.Close();
                isShown = false;
                button1.BackColor = Color.RoyalBlue;
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (isShown == true)
            {
                _dropDownForm.Close();
                isShown = false;

                button1.BackColor = Color.RoyalBlue;
            }
            else if (isShown == false)
            {
                _dropDownForm = new DropDownForm(this);
                _dropDownForm.Location = new Point(this.Location.X + button1.Location.X + 8,  this.Location.Y + button1.Location.Y + 30);
                _dropDownForm.Show();
                isShown = true;
                button1.BackColor = Color.Navy;
                _dropDownForm.LostFocus += new EventHandler(_dropDownForm_LostFocus);
            }
        }


        private void _dropDownForm_LostFocus(object sender, EventArgs e)
        {
            if (isShown)
            {
                _dropDownForm.Close();
                isShown = false;
                button1.BackColor = Color.RoyalBlue;
            }
        }




    }
}
