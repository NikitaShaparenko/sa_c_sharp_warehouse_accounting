﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DropDownControl_CSharp
{
    public partial class DropDownForm : Form
    {
        Form1 frm1;
        public DropDownForm(Form1 F)
        {
            InitializeComponent();
            frm1 = F;
        }



        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.Activate();
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
        }



        Boolean isMouseEnterOnSaveAsButton = true;
        Boolean isAdded = false;

        private void saveAs_button_MouseEnter(object sender, EventArgs e)
        {
            isMouseEnterOnSaveAsButton = true;
            if(isMouseEnterOnSaveAsButton && ! isAdded)
            {
                SaveAs_Options saveasOpt = new SaveAs_Options();
                saveasOpt.Size = optionsPanel.Size;
                saveasOpt.Location = new Point(0, 0);
                optionsPanel.Controls.Add(saveasOpt);
                isAdded = true;
            }
        }

        private void saveAs_button_MouseLeave(object sender, EventArgs e)
        {
            if( !isMouseEnterOnSaveAsButton)
            {
                if(isAdded)
                {
                    optionsPanel.Controls.RemoveAt(0);
                    isAdded = false;
                }
            }
        }


        private void save_button_MouseEnter(object sender, EventArgs e)
        {
            isMouseEnterOnSaveAsButton = false;
            if (!isMouseEnterOnSaveAsButton)
            {
                if (isAdded)
                {
                    optionsPanel.Controls.RemoveAt(0);
                    isAdded = false;
                }
            }
        }

        private void print_button_MouseEnter(object sender, EventArgs e)
        {
            isMouseEnterOnSaveAsButton = false;
            if (!isMouseEnterOnSaveAsButton)
            {
                if (isAdded)
                {
                    optionsPanel.Controls.RemoveAt(0);
                    isAdded = false;
                }
            }
        }

        private void new_button_MouseEnter(object sender, EventArgs e)
        {
            print_button_MouseEnter(sender, e);
        }

        private void open_button_MouseEnter(object sender, EventArgs e)
        {
            print_button_MouseEnter(sender, e);
        }

        private void sendinemail_button_MouseEnter(object sender, EventArgs e)
        {
            print_button_MouseEnter(sender, e);
        }

        private void properties_button_MouseEnter(object sender, EventArgs e)
        {
            print_button_MouseEnter(sender, e);
        }

        private void aboutpaint_button_MouseEnter(object sender, EventArgs e)
        {
            print_button_MouseEnter(sender, e);
        }

        private void exit_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void exit_button_MouseEnter(object sender, EventArgs e)
        {
            print_button_MouseEnter(sender, e);
        }



        private void Top_button_Click(object sender, EventArgs e)
        {
            this.Dispose();
            frm1.isShown = false;
        }


    }
}
