﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DropDownControl_CSharp
{
    public partial class TabForm : Form
    {
        public TabForm()
        {
            InitializeComponent();
        }

        private void TabForm_Load(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;
        }

        static int OldSelTabIndex = 1;

        public Boolean isShown = false;

        TabDropDownForm _dropDownForm;


        protected override void OnMove(EventArgs e)
        {
            base.OnMove(e);
            if (isShown)
            {
                _dropDownForm.Dispose();
                isShown = false;

                tabControl1.SelectedIndex = OldSelTabIndex;
            }

            if(isLoginShown)
            {
                _loginform.Dispose();
                isLoginShown = false;
            }
        }

        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            if (isShown)
            {
                _dropDownForm.Dispose();
                isShown = false;

                tabControl1.SelectedIndex = OldSelTabIndex;
            }

            if (isLoginShown)
            {
                _loginform.Dispose();
                isLoginShown = false;
            }
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            if (isShown)
            {
                _dropDownForm.Dispose();
                isShown = false;

                tabControl1.SelectedIndex = OldSelTabIndex;
            }

            if (isLoginShown)
            {
                _loginform.Dispose();
                isLoginShown = false;
            }
        }


        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
            if (isShown)
            {
                _dropDownForm.Dispose();
                isShown = false;

                tabControl1.SelectedIndex = OldSelTabIndex;
            }

            if (isLoginShown)
            {
                _loginform.Dispose();
                isLoginShown = false;
            }
        }



        private void tabControl1_MouseDown(object sender, MouseEventArgs e)
        {
            Rectangle rect = tabControl1.GetTabRect(0);

            if (rect.Contains(e.Location))
            {
                Size size = this.Size;

                if (isShown == true)
                {
                    _dropDownForm.Dispose();
                    isShown = false;

                    tabControl1.SelectedIndex = OldSelTabIndex;
                }
                else if (isShown == false)
                {
                    _dropDownForm = new TabDropDownForm(this);
                    _dropDownForm.Location = new Point(this.Location.X + rect.X + 8, this.Location.Y + rect.Y + 30);
                    tabControl1.SelectedIndex = OldSelTabIndex;
                    _dropDownForm.Show();
                    isShown = true;
                    _dropDownForm.LostFocus += new EventHandler(_dropDownForm_LostFocus);
                }
            }
            else
            {
                OldSelTabIndex = tabControl1.SelectedIndex;
            }
        }




        private void _dropDownForm_LostFocus(object sender, EventArgs e)
        {
            if (isShown)
            {
                _dropDownForm.Dispose();
                isShown = false;

                tabControl1.SelectedIndex = OldSelTabIndex;
            }
        }


        LoginForm _loginform;
        public Boolean isLoginShown = false;

        //login form show
        private void shapedButton1_Click(object sender, EventArgs e)
        {
            if (isShown == true)
            {
                _loginform.Dispose();
                isShown = false;
            }
            else if (isShown == false)
            {
                _loginform = new LoginForm();
                _loginform.Location = new Point(this.Location.X + shapedButton1.Location.X + 12, shapedButton1.Height + this.Location.Y + shapedButton1.Location.Y + 55);
                _loginform.Show();
                isLoginShown = true;
                _loginform.LostFocus += new EventHandler(_loginForm_LostFocus);
            }
        }

        private void _loginForm_LostFocus(object sender, EventArgs e)
        {
            if (isShown)
            {
                _loginform.Dispose();
                isLoginShown = false;
            }
        }


    }
}
